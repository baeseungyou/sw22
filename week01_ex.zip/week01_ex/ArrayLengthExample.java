package week01_ex;

public class ArrayLengthExample {

}
