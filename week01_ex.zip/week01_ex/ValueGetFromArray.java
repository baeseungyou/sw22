package week01_ex;

public class ValueGetFromArray {

}
